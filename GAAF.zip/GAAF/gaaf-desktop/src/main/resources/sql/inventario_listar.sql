SELECT idInventario, idPedido, idBodega, cantidadTotal, cantidadPorBodega
FROM v_inventario
ORDER BY idInventario;